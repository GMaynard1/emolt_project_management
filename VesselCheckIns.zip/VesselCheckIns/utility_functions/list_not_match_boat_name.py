def list_not_match_boats(vessels):

    import pandas as pd
    import csv
    year='2025'

    # Replace with your CSV file path
    file_path = vessels

    # Load the CSV
    df = pd.read_csv(file_path)

    # Get the first column (boat names)
    boat_names = df.iloc[:, 0].tolist()

    # Print all boat names
    for name in boat_names:
        print(name)

    # If you also want the list form:
    print("\nBoat names list:")
    print(boat_names)

    import boto3

    def list_s3_folders_with_credentials(bucket_name, access_key, secret_key, region_name, prefix='', year=year):
        """
        Lists folders in an S3 bucket using provided access key and secret key.
        """
        s3_client = boto3.client(
            's3',
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region_name
        )

        folders = set()
        paginator = s3_client.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=bucket_name, Prefix=year+'/', Delimiter='/'):
            if 'CommonPrefixes' in page:
                for common_prefix in page['CommonPrefixes']:
                    folders.add(common_prefix['Prefix'])
        print('3')
        name_list= []
        for folder in folders:
            try:
                int(folder.split('/')[1].replace('_', ' '))
                pass
            except:
                name_list.append(folder.split('/')[1].replace('_', ' '))
        return name_list

    bucket_name= 'bkt-ddh'
    access_key= 'AKIA2U6577BK5PPLNNUC'
    secret_key= 'ajiGPK7ej+4V99PUTCkAp7EpvQ5OzLC6rHqVWhqE'
    region_name= 'us-east-1'
    alist= list_s3_folders_with_credentials(bucket_name, access_key, secret_key, region_name, prefix='', year=year)
    #print(alist)

    only_in_list1 = sorted([item for item in alist if item not in boat_names])
    only_in_list2 = sorted([item for item in boat_names if item not in alist])
    
    # # Write to CSV
    # def write_csv(filename, items):
        # with open(filename, mode="w", newline="", encoding="utf-8") as file:
            # writer = csv.writer(file)
            # writer.writerow(["vessels"])  # header
            # for item in items:
                # writer.writerow([item])

    # write_csv("VesselCheckIns/only_in_S3.csv", only_in_list1)
    # write_csv("VesselCheckIns/only_in_database.csv", only_in_list2)

    # print("CSV files created: only_in_S3.csv, only_in_database.csv")
    return only_in_list1, only_in_list2
