def list_portal_boats():
  import requests
  
  BASE = "https://www.portal.emolt.net"
  token_res = requests.post(f"{BASE}/api/token-auth/", data={
      "username": "emolt",
      "password": "jzi!$3NE32"
  }, timeout=10)
  
  token_res.raise_for_status()
  token = token_res.json()["token"]
  
  r = requests.get(f"{BASE}/api/my-vessels/",
                   headers={"Authorization": f"Token {token}"},
                   timeout=10)
  r.raise_for_status()
  vessels = r.json()["vessels"]
  return(vessels)



